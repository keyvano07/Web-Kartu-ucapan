import { motion } from "motion/react";

const Petal = ({ cx, cy, r, color, rotation }: { cx: number; cy: number; r: number; color: string; rotation: number }) => (
  <ellipse
    cx={cx}
    cy={cy}
    rx={r * 0.55}
    ry={r}
    fill={color}
    transform={`rotate(${rotation} ${cx} ${cy})`}
    opacity={0.85}
  />
);

const Flower = ({ x, y, size, petals, petalColor, centerColor }: {
  x: number; y: number; size: number; petals: number; petalColor: string; centerColor: string;
}) => {
  const angles = Array.from({ length: petals }, (_, i) => (360 / petals) * i);
  return (
    <g transform={`translate(${x} ${y})`}>
      {angles.map((angle, i) => (
        <Petal key={i} cx={0} cy={-size * 0.7} r={size * 0.55} color={petalColor} rotation={angle} />
      ))}
      <circle cx={0} cy={0} r={size * 0.32} fill={centerColor} />
      <circle cx={0} cy={0} r={size * 0.18} fill="#fff7e6" opacity={0.7} />
    </g>
  );
};

const Leaf = ({ x, y, size, rotation, color }: { x: number; y: number; size: number; rotation: number; color: string }) => (
  <g transform={`translate(${x} ${y}) rotate(${rotation})`}>
    <ellipse cx={0} cy={-size * 0.5} rx={size * 0.3} ry={size * 0.6} fill={color} opacity={0.75} />
    <line x1={0} y1={0} x2={0} y2={-size} stroke="#5a8a40" strokeWidth={0.8} opacity={0.5} />
  </g>
);

const FloralCorner = ({ flip }: { flip: boolean }) => (
  <svg
    viewBox="0 0 180 180"
    className="absolute w-40 h-40 md:w-52 md:h-52"
    style={{
      top: flip ? "auto" : 0,
      bottom: flip ? 0 : "auto",
      left: flip ? "auto" : 0,
      right: flip ? 0 : "auto",
      transform: flip ? "rotate(180deg)" : "none",
      pointerEvents: "none",
    }}
  >
    {/* Stems */}
    <path d="M10 170 Q50 130 80 90" stroke="#7aad55" strokeWidth="2.5" fill="none" opacity="0.6" />
    <path d="M10 170 Q30 110 60 60" stroke="#7aad55" strokeWidth="2" fill="none" opacity="0.5" />
    <path d="M10 170 Q70 150 120 140" stroke="#7aad55" strokeWidth="2" fill="none" opacity="0.5" />

    {/* Leaves */}
    <Leaf x={45} y={130} size={22} rotation={-40} color="#7aad55" />
    <Leaf x={65} y={100} size={18} rotation={20} color="#5a9940" />
    <Leaf x={90} y={145} size={16} rotation={-70} color="#6aaa48" />

    {/* Flowers */}
    <Flower x={80} y={88} size={20} petals={6} petalColor="#e8779a" centerColor="#f5c03a" />
    <Flower x={50} y={52} size={16} petals={5} petalColor="#f4a0c0" centerColor="#e8a020" />
    <Flower x={120} y={135} size={14} petals={5} petalColor="#c86090" centerColor="#f5c03a" />
    <Flower x={100} y={70} size={12} petals={6} petalColor="#f8c0d8" centerColor="#f09030" />

    {/* Small buds */}
    <circle cx={65} cy={78} r={5} fill="#f4a0c0" opacity="0.8" />
    <circle cx={110} cy={110} r={4} fill="#e8779a" opacity="0.7" />
  </svg>
);

const SparkleRow = () => (
  <div className="flex items-center justify-center gap-3 my-2">
    {["✦", "✧", "✦", "✧", "✦"].map((s, i) => (
      <motion.span
        key={i}
        className="text-amber-400 text-xs"
        animate={{ opacity: [0.4, 1, 0.4], scale: [0.8, 1.2, 0.8] }}
        transition={{ duration: 2, delay: i * 0.3, repeat: Infinity }}
      >
        {s}
      </motion.span>
    ))}
  </div>
);

export default function App() {
  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 md:p-8"
      style={{
        background: "radial-gradient(ellipse at 60% 40%, #fde8d8 0%, #f9d5e0 40%, #fdf0f5 100%)",
        fontFamily: "'Lato', sans-serif",
      }}
    >
      {/* Floating petals background */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full opacity-20 pointer-events-none"
          style={{
            width: `${10 + (i % 3) * 8}px`,
            height: `${14 + (i % 3) * 10}px`,
            background: i % 2 === 0 ? "#e8779a" : "#f4a0c0",
            left: `${8 + i * 11}%`,
            top: `${10 + ((i * 17) % 70)}%`,
            borderRadius: "50% 20% 50% 20%",
          }}
          animate={{
            y: [0, -18, 0],
            rotate: [0, 15, -10, 0],
            opacity: [0.15, 0.25, 0.15],
          }}
          transition={{ duration: 4 + i * 0.5, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}

      {/* Card */}
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-md md:max-w-lg overflow-hidden"
        style={{
          background: "linear-gradient(155deg, #fff8f2 0%, #fff0f5 50%, #fdf5e8 100%)",
          borderRadius: "2rem",
          boxShadow: "0 8px 60px rgba(155,58,90,0.18), 0 2px 12px rgba(0,0,0,0.06)",
          border: "1.5px solid rgba(155,58,90,0.14)",
        }}
      >
        {/* Floral corners */}
        <FloralCorner flip={false} />
        <FloralCorner flip={true} />

        {/* Gold border frame inner */}
        <div
          className="absolute inset-4 pointer-events-none"
          style={{
            border: "1px solid rgba(200,132,58,0.28)",
            borderRadius: "1.5rem",
          }}
        />

        {/* Content */}
        <div className="relative z-10 flex flex-col items-center text-center px-10 md:px-16 py-16 md:py-20">

          {/* Top label */}
          <motion.p
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="text-xs tracking-[0.3em] uppercase mb-3"
            style={{ color: "#9b3a5a", fontFamily: "'Lato', sans-serif", fontWeight: 300 }}
          >
            with love &amp; warmth
          </motion.p>

          <SparkleRow />

          {/* Main greeting */}
          <motion.h1
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 0.8, ease: "easeOut" }}
            className="mt-4 leading-tight"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "clamp(2rem, 6vw, 2.8rem)",
              fontWeight: 700,
              color: "#7a1f3a",
              lineHeight: 1.25,
            }}
          >
            Selamat
            <br />
            <span style={{ fontStyle: "italic", color: "#9b3a5a" }}>Hari Jadi</span>
          </motion.h1>

          {/* Name highlight */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.75, duration: 0.7 }}
            className="mt-5 mb-2 px-8 py-3 rounded-full"
            style={{
              background: "linear-gradient(90deg, #9b3a5a 0%, #c05070 50%, #9b3a5a 100%)",
              boxShadow: "0 4px 20px rgba(155,58,90,0.35)",
            }}
          >
            <p
              style={{
                fontFamily: "'Dancing Script', cursive",
                fontSize: "clamp(1.6rem, 5vw, 2.2rem)",
                fontWeight: 700,
                color: "#fff8f2",
                letterSpacing: "0.04em",
              }}
            >
              Nenek Nini
            </p>
          </motion.div>

          {/* Decorative divider */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.9, duration: 0.8 }}
            className="flex items-center gap-3 my-5 w-full justify-center"
          >
            <div className="h-px flex-1 max-w-16" style={{ background: "linear-gradient(90deg, transparent, #c8843a)" }} />
            <svg width="20" height="20" viewBox="0 0 20 20">
              <path d="M10 2 L11.5 8.5 L18 10 L11.5 11.5 L10 18 L8.5 11.5 L2 10 L8.5 8.5 Z" fill="#c8843a" opacity="0.85" />
            </svg>
            <div className="h-px flex-1 max-w-16" style={{ background: "linear-gradient(90deg, #c8843a, transparent)" }} />
          </motion.div>

          {/* Heartfelt message */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.0, duration: 0.8 }}
            className="text-sm md:text-base leading-relaxed max-w-xs"
            style={{
              fontFamily: "'Lato', sans-serif",
              color: "#6b3040",
              fontWeight: 300,
              letterSpacing: "0.01em",
            }}
          >
            Semoga nenek selalu diberikan kesehatan, kebahagiaan, dan kasih sayang yang berlimpah.
          </motion.p>

          {/* Second divider */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1, duration: 0.6 }}
            className="flex items-center gap-2 my-5"
          >
            {["❀", "❁", "❀"].map((f, i) => (
              <span key={i} style={{ color: "#e8779a", fontSize: "0.85rem" }}>{f}</span>
            ))}
          </motion.div>

          {/* From section */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2, duration: 0.7 }}
            className="flex flex-col items-center gap-1"
          >
            <p
              className="text-xs tracking-widest uppercase mb-2"
              style={{ color: "#8a6050", fontWeight: 400, fontFamily: "'Lato', sans-serif" }}
            >
              Dari Cucunda
            </p>
            <div className="flex items-center gap-2">
              {["Dipta", "Dias", "Ditri"].map((name, i) => (
                <motion.span
                  key={name}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 1.3 + i * 0.15, duration: 0.5 }}
                >
                  <span
                    className="inline-block px-3 py-1 rounded-full text-sm"
                    style={{
                      fontFamily: "'Dancing Script', cursive",
                      fontSize: "1.05rem",
                      fontWeight: 600,
                      color: "#7a1f3a",
                      background: "rgba(155,58,90,0.08)",
                      border: "1px solid rgba(155,58,90,0.18)",
                    }}
                  >
                    {name}
                  </span>
                  {i < 2 && (
                    <span className="mx-0.5" style={{ color: "#e8779a", fontSize: "0.7rem" }}>✦</span>
                  )}
                </motion.span>
              ))}
            </div>
          </motion.div>

          {/* Bottom sparkles */}
          <div className="mt-6">
            <SparkleRow />
          </div>
        </div>
      </motion.div>
    </div>
  );
}
